import csv

salary_map = {
    "Разработчик": 120000,
    "Менеджер": 100000,
    "Дизайнер": 90000
}

with open('csv_file.csv', 'r', encoding='utf-8') as infile, \
     open('employees_with_salary.csv', 'w', newline='', encoding='utf-8') as outfile:

    reader = csv.DictReader(infile)
    fieldnames = reader.fieldnames + ['Зарплата']
    writer = csv.DictWriter(outfile, fieldnames=fieldnames)
    writer.writeheader()

    for row in reader:
        position = row['Должность']
        row['Зарплата'] = salary_map.get(position, 0) 
        writer.writerow(row)



