import csv
import json

CSV_PATH = "animals.csv"
JSON_PATH = "zoo.json"

with open(CSV_PATH, mode="r", encoding="utf-8", newline="") as f:
    reader = csv.DictReader(f)          
    data = list(reader)

with open(JSON_PATH, mode="w", encoding="utf-8") as f:
    json.dump(data, f, ensure_ascii=False, indent=2)  
print(f"Saved {len(data)} records to {JSON_PATH}")
